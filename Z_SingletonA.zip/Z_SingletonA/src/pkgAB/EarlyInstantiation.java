package pkgAB;

public class EarlyInstantiation {
	
	private static EarlyInstantiation early = new EarlyInstantiation();
	
	private EarlyInstantiation () {}
	
	public static EarlyInstantiation getEarlyObj() {
		
		return early;
	}
	
	public void doPrintObj() {
		
		System.out.println("From doPrintObj="+early);
		System.out.println("getEarlyObj -->="+getEarlyObj());
	}

	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EarlyInstantiation e = new EarlyInstantiation();
		e.doPrintObj();
		System.out.println("From main      ="+early);
		System.out.println("getEarlyObj ==>="+getEarlyObj());
		
		early = null;
		e.doPrintObj();
		System.out.println("From main      ="+early);
		System.out.println("getEarlyObj ==>="+getEarlyObj());

	}

}
