package pkgAB;

public class LazyInstantiation {
	
	private static LazyInstantiation lazyObj = new LazyInstantiation();
	
	public LazyInstantiation() {}
	
	private static LazyInstantiation getLazyObj() {
		
		if(lazyObj == null) {
			synchronized (LazyInstantiation.class) {
				if(lazyObj == null) {
					lazyObj = new LazyInstantiation();
				}
				
			}
		}
		
		return lazyObj;
	}
	
	public void doPrintObj() {
		System.out.println("From doPrintObj="+lazyObj);
		//System.out.println("getLazyObj---->="+getLazyObj());
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LazyInstantiation l = new LazyInstantiation();
		l.doPrintObj();		
		System.out.println("From main      ="+lazyObj);
		System.out.println("getLazyObj ===>="+getLazyObj());
		
		lazyObj = null;
		
		System.out.println("......From main After nullify.....");
		
		l.doPrintObj();		
		System.out.println("From main      ="+lazyObj);	
		
		System.out.println("getLazyObj ===>="+getLazyObj());
		l.doPrintObj();		
		System.out.println("From main      ="+lazyObj);	
		

	}

}
